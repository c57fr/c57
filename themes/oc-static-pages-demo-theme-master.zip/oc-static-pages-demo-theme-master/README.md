OctoberCMS Static Pages demo theme
==========================

Demo theme for the OctoberCMS [Static Pages tutorial blog post](http://octobercms.com/blog/post/getting-started-static-pages).
